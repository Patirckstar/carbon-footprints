// API客户端工具

const API_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"

// 获取存储的令牌
const getToken = () => {
  if (typeof window !== "undefined") {
    return localStorage.getItem("token")
  }
  return null
}

// 基本请求函数
const request = async (endpoint: string, method = "GET", data: any = null) => {
  const token = getToken()

  const headers: HeadersInit = {
    "Content-Type": "application/json",
  }

  if (token) {
    headers["x-auth-token"] = token
  }

  const config: RequestInit = {
    method,
    headers,
    body: data ? JSON.stringify(data) : null,
  }

  try {
    const response = await fetch(`${API_URL}${endpoint}`, config)
    const responseData = await response.json()

    if (!response.ok) {
      throw new Error(responseData.message || "请求失败")
    }

    return responseData
  } catch (error) {
    console.error("API请求错误:", error)
    throw error
  }
}

// API函数
export const api = {
  // 用户认证
  auth: {
    register: (userData: any) => request("/users/register", "POST", userData),
    login: (credentials: any) => request("/users/login", "POST", credentials),
    getCurrentUser: () => request("/users/me"),
  },

  // 碳足迹计算
  calculations: {
    save: (calculationData: any) => request("/calculations", "POST", calculationData),
    getAll: () => request("/calculations"),
    getById: (id: string) => request(`/calculations/${id}`),
    delete: (id: string) => request(`/calculations/${id}`, "DELETE"),
  },
}

// 认证工具
export const auth = {
  isAuthenticated: () => !!getToken(),

  login: (token: string) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("token", token)
    }
  },

  logout: () => {
    if (typeof window !== "undefined") {
      localStorage.removeItem("token")
    }
  },
}
