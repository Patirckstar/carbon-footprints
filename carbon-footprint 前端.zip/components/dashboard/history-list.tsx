"use client"

import { useEffect, useState } from "react"
import { format } from "date-fns"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trash2, Eye } from "lucide-react"
import { api } from "@/lib/api"
import { useRouter } from "next/navigation"

interface Calculation {
  _id: string
  date: string
  results: {
    energy: number
    transportation: number
    food: number
    waste: number
    lifestyle: number
    total: number
  }
}

export function HistoryList() {
  const [calculations, setCalculations] = useState<Calculation[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState("")
  const router = useRouter()

  useEffect(() => {
    const fetchCalculations = async () => {
      try {
        const data = await api.calculations.getAll()
        setCalculations(data)
      } catch (err: any) {
        setError(err.message || "获取历史记录失败")
      } finally {
        setIsLoading(false)
      }
    }

    fetchCalculations()
  }, [])

  const handleDelete = async (id: string) => {
    if (window.confirm("确定要删除这条记录吗？")) {
      try {
        await api.calculations.delete(id)
        setCalculations(calculations.filter((calc) => calc._id !== id))
      } catch (err: any) {
        setError(err.message || "删除记录失败")
      }
    }
  }

  const handleView = (id: string) => {
    router.push(`/calculation/${id}`)
  }

  if (isLoading) {
    return <div className="text-center py-8">加载中...</div>
  }

  if (error) {
    return <div className="text-center text-red-500 py-8">{error}</div>
  }

  if (calculations.length === 0) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <p>您还没有碳足迹计算记录</p>
          <Button onClick={() => router.push("/calculator")} className="mt-4 bg-green-600 hover:bg-green-700">
            开始计算
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>您的碳足迹历史记录</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {calculations.map((calc) => (
            <div
              key={calc._id}
              className="flex justify-between items-center p-4 border rounded-lg hover:bg-gray-50 dark:hover:bg-gray-800"
            >
              <div>
                <p className="font-medium">{format(new Date(calc.date), "yyyy年MM月dd日 HH:mm")}</p>
                <p className="text-sm text-gray-500">总碳足迹: {calc.results.total.toFixed(2)} kg CO₂</p>
              </div>
              <div className="flex space-x-2">
                <Button size="sm" variant="outline" onClick={() => handleView(calc._id)}>
                  <Eye className="h-4 w-4 mr-1" />
                  查看
                </Button>
                <Button size="sm" variant="destructive" onClick={() => handleDelete(calc._id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
